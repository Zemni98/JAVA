package com.computer;

public interface Graphic {
	
	public double rendering(int size);
	
}
