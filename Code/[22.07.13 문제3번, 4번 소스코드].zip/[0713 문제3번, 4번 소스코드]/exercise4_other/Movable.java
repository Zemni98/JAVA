package exercise4_other;

public interface Movable {

	public void move(int x, int y);
	
}
