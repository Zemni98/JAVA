package exercise4;

public interface Movable {

	public void move(int x, int y);
	
}
